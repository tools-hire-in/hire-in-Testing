# E-Sign Feature — Source Export

Exported from the **Hire'in Solutions** platform. This package contains every file that makes up the digital-signature feature. Wire the files into your own project and install the dependencies listed below.

---

## File Inventory

### `server/documentSigningService.ts`
**Central cryptographic signing service.** All HMAC-SHA256 signing logic lives here:
- `signOfferLetterContent` — content-bound HMAC using a DOCX buffer
- `signOfferLetterAcceptance` — JSON-field HMAC for offer-letter acceptance
- `signOfferCountersign` / `signAddendumAcceptance` / `signAddendumCountersign` — per-entity signing functions
- `signHrLetter` — pipe-delimited HMAC for HR letters (experience, internship, relieving)
- `signContract` — canonical-payload HMAC for staffing contracts
- `signPolicyAcknowledgement` — binds policy identity + page initials + final signature
- `recordSignature` — append-only signature ledger writer (non-fatal)
- `verifyDocument` — dispatcher that re-computes HMAC and compares timing-safely
- `timingSafeAuthEqual` — constant-time string comparison helper

**Env vars required:** `OFFER_SIGNING_KEY` (all doc types), `LETTER_HMAC_SECRET` (HR letters, falls back to `OFFER_SIGNING_KEY` if unset).

---

### `server/hrLetterPdf.ts`
**PDF generator for HR letters** (experience, internship, relieving). Uses `pdfkit` to build a branded A4 PDF with header, body paragraphs chosen by performance/conduct band, cursive signatory name (if `DancingScript.ttf` is present at `server/fonts/`), optional company seal, and a reference + auth-code footer for verifiability.

Imports sentence maps from `shared/hrLetterConstants.ts`.

---

### `server/policySigningRoutes.ts`
**Express route handlers for the policy sign-off module:**
- HR routes: list policies, push to employees, resend requests, export CSV
- Employee routes: fetch pending requests, load policy content, submit initials + final signature

On signature submission it calls `generatePolicySignaturePdf` (not included — write your own or omit) and uploads to object storage, then calls `signPolicyAcknowledgement` + `recordSignature`.

---

### `server/contractRoutes.ts`
**Express route handlers for the contracts module:**
- Template CRUD, client registry CRUD
- Contract generation from a DOCX template (uses `docxtemplater`)
- Free-form MSA builder (`buildFreeformMsaDocx` — not included)
- Import (upload existing PDF/DOCX)
- Send for client e-signing (dispatches a signed link)
- Public token-based signing endpoint — applies `signContract` + `recordSignature`
- Countersign by internal user

---

### `server/rateLimits.ts`
**`express-rate-limit` instances** used by the signing routes:
- `loginLimiter` — 10 req / 15 min
- `vaultRevealLimiter` / `vaultCopyLimiter`
- `tokenLookupLimiter` — 20 req/min (prod) / 200 (dev), used on public signing token endpoints
- `verifyLetterLimiter` — 30 req/min (prod) / 300 (dev), used on `/api/verify-letter`

---

### `shared/schema.ts`
**Full Drizzle ORM schema** for the entire platform. Extract the tables relevant to e-sign:
- `signatureRecords` — append-only unified ledger (`document_type`, `document_id`, `auth_code`, `content_hash`, `signer_*`, `ip_address`, …)
- `hrLetters` — HR letter rows with `reference_number`, `auth_code`, `document_hash`
- `offerLetters` — with `auth_code`, `document_hash`, `accepted_name`, `accepted_at`, `annexure_initials`
- `offerLetterAddendums` — with `auth_code`, `document_hash`
- `contracts` — with `reference_number`, `auth_code`, `document_hash`, `signed_at`
- `policyDocuments`, `policySigningRequests`, `policySignatures`

---

### `shared/verifySchema.ts`
**Zod validation schema** for the public `/verify` endpoint. Exports:
- `ALLOWED_DOC_TYPES` and `AllowedDocType` type
- `REF_PATTERNS` — regex per doc type (`RL/…`, `CTR/…`, `OL/…`, `AM/…`)
- `inferDocType(ref)` — auto-detect doc type from prefix
- `refMatchesDocType(ref, docType)` — validate ref against its pattern
- `verifyInputSchema` — Zod schema that normalises + validates `{ ref, auth, documentType }`

Used on both server (request validation) and client (live field hints).

---

### `shared/hrLetterConstants.ts`
**Static lookup tables** for HR letter generation:
- `PERFORMANCE_BAND_SENTENCES`, `CONDUCT_BAND_SENTENCES`, `COMPLETION_BAND_SENTENCES`, `CLOSING_LINE_SENTENCES` — keyed text blocks interpolated into PDF body
- `TEMPLATE_PREFIX_MAP` — maps template type (`experience`, `relieving`, …) to reference prefix (`EXP`, `REL`, …)
- `TEMPLATE_LABELS`, `AMENDMENT_TEMPLATE_TYPES`
- `ROLE_RESPONSIBILITY_SUMMARIES` — predefined responsibility paragraphs by designation (Healthcare/IT Recruiter)

---

### `client/src/pages/VerifyLetter.tsx`
**Public document verification page** (`/verify`). Users enter a reference number and auth code; the page auto-detects the document type from the prefix, validates formats client-side with `verifySchema`, and calls `GET /api/verify-letter`. Renders distinct result cards for HR letters, contracts, offer letters, and addendums. Displays tamper warnings.

---

### `client/src/components/esign/SignatureBlock.tsx`
**Reusable e-signature form atom.** Renders the interactive signing widget used by every acceptance flow (offer letters, addendums, contracts, policies):
- Optional consent checkbox (plain or boxed)
- Typed-name confirmation with exact-match validation
- Optional signing-date field
- Live cursive signature preview (Dancing Script font)
- DocuSign mode: pre-filled name + chosen font from `EsignSetup`
- Disabled submit button until all gates pass

---

### `client/src/components/esign/EsignSetup.tsx`
**DocuSign-style setup step** shown before the signing form. Lets the user type their full name, choose a cursive font style (Dancing Script / Pacifico / Caveat), and previews both the signature and auto-derived initials. Returns `{ name, initials, font }` via `onComplete`.

---

### `client/src/components/esign/AnnexureInitialing.tsx`
**Policy annexure review + initialing widget.** Given a list of annexure keys, it:
- Fetches annexure content from `/api/annexure-content`
- Renders a row per annexure with a read dialog and an initials input
- In DocuSign mode (`presetInitials` supplied): auto-fills initials and shows sequential Confirm buttons with auto-scroll advance
- Calls `onAllConfirmed` when every annexure is initialed/confirmed

---

## npm Dependencies to Install

```bash
# Core
npm install express express-rate-limit express-session zod drizzle-orm

# Crypto (Node built-in — no install needed)
# crypto

# PDF generation
npm install pdfkit
npm install -D @types/pdfkit

# DOCX generation (for addendums / contracts)
npm install docx docxtemplater pizzip

# Password / session
npm install bcrypt
npm install -D @types/bcrypt

# File uploads
npm install multer
npm install -D @types/multer

# Database driver
npm install pg
npm install -D @types/pg

# Frontend (React)
npm install @tanstack/react-query react-hook-form @hookform/resolvers zod
```

## Environment Variables

| Variable | Purpose |
|---|---|
| `OFFER_SIGNING_KEY` | Master HMAC key for offer letters, addendums, contracts |
| `LETTER_HMAC_SECRET` | HMAC key for HR letters (falls back to `OFFER_SIGNING_KEY`) |
| `SESSION_SECRET` | Express session secret |
| `DATABASE_URL` | PostgreSQL connection string |

## Notes

- `shared/schema.ts` is the full platform schema — copy only the tables you need.
- The `signatureRecords` table is the append-only audit ledger; every signing flow writes to it *after* updating the per-entity row.
- All HMAC operations use `crypto.timingSafeEqual` for auth-code comparison to prevent timing attacks.
- Rate limits in `rateLimits.ts` are lower in production (`NODE_ENV=production`) — tune `max` values to suit your traffic.
- `hrLetterPdf.ts` looks for a `DancingScript.ttf` font at `server/fonts/DancingScript.ttf`; remove or adjust that path if you don't have the font.
